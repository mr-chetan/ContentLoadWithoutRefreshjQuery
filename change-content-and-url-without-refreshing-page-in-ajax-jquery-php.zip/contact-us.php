<?php include 'header.php'; ?>
	<div class="page">
		<h1>This Is <strong>Contact Us</strong> Page</h1>
	</div>
<?php if($_GET['rel']!='tab'){ echo "</div>";} ?>
<?php include('footer.php'); ?>